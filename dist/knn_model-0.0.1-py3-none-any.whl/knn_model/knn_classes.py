import numpy as np
import pandas as pd
from math import sqrt
from sklearn.metrics import r2_score, mean_squared_error, explained_variance_score
from sklearn.metrics import accuracy_score, f1_score, precision_score, recall_score
from knn_model.c_index import c_index
from sklearn.base import BaseEstimator, TransformerMixin
from sklearn.base import clone
from sklearn.neighbors import KNeighborsRegressor
import random
from statistics import mean
import warnings

warnings.filterwarnings("ignore")


class SpatialKNeighborsRegressor(BaseEstimator, TransformerMixin):
    """ TODO description """

    def __init__(self, n_neighbors=5, metric='euclidean'):
        self.isFitted = False
        self.X_train = None
        self.y_train = None

        # List of distances in meters of the dead zone radius... #TODO
        self.cv_dead_zone_r = [0, 100]

        # To store the p_values of the spatial-CV for each of the radius in self.cv_dead_zone_r
        self.p_values_radius = {}

        self.n_neighbors = n_neighbors
        self.metric = metric
        self.estimator = KNeighborsRegressor(n_neighbors=self.n_neighbors, metric=self.metric)

    def get_geographical_distance(self, coordinates_1, coordinates_2):
        """ Calculates the geographic distance between 2 pair of coordinates """
        x1, y1 = coordinates_1
        x2, y2 = coordinates_2
        distance = sqrt(((x1 - x2) ** 2) + ((y1 - y2) ** 2))

        return distance

    def set_geographic_p_values(self):
        """  # TODO explanation"""
        assert self.isFitted, "The model hasn't been fitted yet"
        X = self.X_train.copy()
        y = self.y_train.copy()
        # Clone the self.estimator to avoid changes in its configuration
        estimator = clone(self.estimator)

        y_df = pd.DataFrame(y, columns=['target'])
        df = pd.concat([X, y_df], axis=1)

        predictions = []
        for index, sample in df.iterrows():
            sample_xy = (sample['coordinate_x'], sample['coordinate_y'])

            # Calculate geographic distances
            df['distance'] = df.apply(
                lambda x: self.get_geographical_distance(sample_xy,
                                            (x['coordinate_x'], x['coordinate_y'])), axis=1)

            for radius in self.cv_dead_zone_r:
                # Remove from the training data set the samples that are inside dead_zone_distance
                df_cleaned = df[df['distance'] > radius]
                X_train = df_cleaned.drop(['coordinate_x', 'coordinate_y', 'distance', 'target'],
                                          axis=1)
                y_train = df_cleaned['target']

                X_test = sample.drop(['coordinate_x', 'coordinate_y', 'target'])
                X_test = np.array(X_test).reshape(1, -1)

                # Make prediction
                pred = estimator.fit(X_train, y_train).predict(X_test)
                predictions.append(pred[0])

        # Evaluate predictions
        score = scoring(y, predictions)

        if verbose:
            print(f"\nScore: {score}\n")

        df_predictions = pd.DataFrame.from_records({'y_test': list(y), 'y_pred': predictions})
        dict_results = {'score': score, 'df_results': df_predictions}

        return dict_results

    def fit(self, X, y):
        X = X.copy()
        y = y.copy()
        self.X_train = X.copy()
        self.y_train = y.copy()
        self.isFitted = True

        self.estimator.fit(X.drop(['coordinate_x', 'coordinate_y'], axis=1), y)
        # TODO
        # make new function with permutation_test_score() inside self.spatial_cross_validation()

        # Do a spatial-CV and calculate the p_value for each radius in self.cv_dead_zone_r
        self.set_geographic_p_values()

        return self

    def predict(self, X):
        """ Returns the prediction/s together with the p_value/s of that predriction/s.
         The p_value depends on the geographic distance from the point we are predicting
         to the k nearest neighbors used to make the prediction. """

        X = X.copy()

        prediction = self.estimator.predict(X.drop(['coordinate_x', 'coordinate_y'], axis=1))
        p_value = self.geographic_pred_scoring(X)

        return prediction, p_value

    def score(self, X, y):
        score = self.estimator.score(X, y)
        return score


class KNNRegressor(BaseEstimator, TransformerMixin):
    """ k Nearest Neighbors prediction model (regression).
    This class can be integrated in most sklearn pipelines as it inherits from
    BaseEstimator/TransformerMixin, and implements the basic sklearn methods. """

    def __init__(self, n_neighbors=5):
        self.n_neighbors = n_neighbors
        self.X_train = None
        self.y_train = None
        self.isFitted = False

    def c_index(self, true_labels, predictions):
        """ Calculates the C-index"""

        true_labels = list(true_labels)
        predictions = list(predictions)

        n = 0
        h_sum = 0
        for i in range(len(true_labels)):
            t = true_labels[i]
            p = predictions[i]
            for j in range(i + 1, len(true_labels)):
                nt = true_labels[j]
                np = predictions[j]
                if t != nt:
                    n += 1
                    if (p < np and t < nt) or (p > np and t > nt):
                        h_sum += 1
                    elif p == np:
                        h_sum += 0.5
        # To avoid 'ZeroDivisionError' exception
        if n == 0:
            return h_sum
        return h_sum / n

    def euclidean_distance(self, row1, row2):
        """Calculates the Euclidean distance between two vectors"""

        distance = 0.0
        for i in range(len(row1) - 1):
            distance += (row1[i] - row2[i]) ** 2

        return sqrt(distance)

    def get_distances(self, X):
        """Returns a list with all distances"""

        distances = []

        for index, train_row in self.X_train.iterrows():
            dist = self.euclidean_distance(X, train_row)
            distances.append((self.y_train.iloc[index], dist))

        return distances

    def get_neighbors(self, X, n_neighbors=None):
        """Returns the n closest neighbors"""

        assert self.isFitted, " The model hasn't been fit yet"

        if not n_neighbors:
            n_neighbors = self.n_neighbors

        distances = self.get_distances(X)
        distances.sort(key=lambda tup: tup[1])
        neighbors = []
        for i in range(n_neighbors):
            neighbors.append(distances[i][0])

        return neighbors

    def fit(self, X, y):
        """Fits the model to the training data"""

        # Check that the data is in the right format and data type
        X, y = self.data_validation(X, y)

        self.X_train = X.copy().reset_index(drop=True)
        self.y_train = y.copy().reset_index(drop=True)
        self.isFitted = True

        return self

    def predict(self, X):
        """Makes one or multiple predictions"""

        assert self.isFitted, " The model hasn't been fit yet"

        X = self.data_validation(X)

        predictions = []
        if isinstance(X, pd.DataFrame):
            for index, row in X.iterrows():
                neighbors = self.get_neighbors(row)
                predictions.append(mean(neighbors))

        else:
            neighbors = self.get_neighbors(X)
            predictions.append(mean(neighbors))

        return predictions

    def get_scoring_func(self, scoring):
        """Returns a scoring function"""

        default_scoring_function = mean_squared_error

        if scoring == "r2":
            scoring_func = r2_score
        elif scoring == "mse":
            scoring_func = mean_squared_error
        elif scoring == "expvar":
            scoring_func = explained_variance_score
        elif scoring == "c_index":
            scoring_func = c_index
        else:
            scoring_func = default_scoring_function
            print(f"Scoring '{scoring}' not known, default scoring function"
                  f" ({default_scoring_function.__name__}) returned.")

        return scoring_func

    def score(self, X, y, scoring='r2'):
        """Makes a prediction and returns its scoring"""

        assert self.isFitted, " The model hasn't been fit yet"

        scoring_func = self.get_scoring_func(scoring)

        X = self.data_validation(X)

        y_real = y
        y_predicted = self.predict(X)
        score = scoring_func(list(y_real), list(y_predicted))

        return score

    def data_validation(self, X, y=None, y_check=False):
        """Checks that the data is in the right format and data type"""
        # Check X:
        # Convert to dataframe if it is a np.dnarray
        if isinstance(X, np.ndarray):
            X = pd.DataFrame(X)
        # Check input data type
        assert isinstance(X, pd.DataFrame) or isinstance(X, pd.Series)
        # Check tha the dataframe only contains numeric values
        assert all(np.issubdtype(dtype, np.number) for dtype in
                   X.dtypes), "X dataframe must contain only numerical values"
        # Check that there aren't missing values
        assert not X.isnull().values.any(), "X contains missing values"

        # Check y:
        if y is not None:
            # Convert to dataframe if it is a np.dnarray
            if isinstance(y, np.ndarray):
                y = pd.DataFrame(y)
            # Check input data type
            assert isinstance(y, pd.DataFrame) or isinstance(y, pd.Series)
            assert len(X) == len(y), "X and y must have same lenght"
            # Check that there aren't missing values
            assert not y.isnull().values.any(), "X contains missing values"

            return X, y
        return X

    def cross_validation(self, cv=10, n_neighbors=5, refit=False, verbose=True, scoring='r2'):
        """Performs a cross-validation reusing the distances"""

        assert self.isFitted, " The model hasn't been fit yet"

        scoring_func = self.get_scoring_func(scoring)

        X = self.X_train.copy()
        y = self.y_train.copy()
        indexes = list(X.index.values)
        random.Random(4).shuffle(indexes)

        # Get the distances for all the rows of the data
        distances_matrix = [self.get_distances(row) for index, row in self.X_train.iterrows()]

        # Convert to a list if it is not a list
        if not isinstance(n_neighbors, list):
            n_neighbors = [n_neighbors]
        else:
            n_neighbors = n_neighbors

        cv = cv

        sample_size = (len(X) - 1) // cv

        # Create dataframe to store the r2 scores
        df_results = pd.DataFrame([[None for n in n_neighbors] for i in range(cv)])
        df_results.columns = [n for n in n_neighbors]
        df_results.index.name = "CV"

        for i in range(cv):
            sample = [indexes.pop(0) for i in range(sample_size)]
            X_test = X.loc[sample]
            y_test = y.loc[sample]

            # Create a dataframe to store the predictions
            df_predictions = pd.DataFrame([[None for n in n_neighbors] for i in sample])
            df_predictions.index = sample
            df_predictions.columns = [n for n in n_neighbors]

            for index, row in X_test.iterrows():
                # Get all the distances for that data point
                distances = distances_matrix[index].copy()

                # Remove the distances of the data points that are present in the test set.
                # We need to start removing them in descendant order to avoid the change
                # of index every time an item is removed.
                for x in sorted(sample)[::-1]:
                    del distances[x]

                # Sort the distances
                distances.sort(key=lambda tup: tup[1])

                # Make a prediction for each of the n_neighbors values
                for n in n_neighbors:
                    # Get the closest n neighbours
                    df_predictions.loc[index][n] = mean([i[0] for i in distances[:n]])

            # Score the prediction and add it to the results dataframe
            for n in n_neighbors:
                y_pred = df_predictions[n].values
                score = scoring_func(y_test, y_pred)
                df_results.loc[i][n] = score

        if scoring == 'mse':
            # Sort in ascending order
            best_score = df_results.mean().sort_values(ascending=True).values[0]
            best_n_neighbors = df_results.mean().sort_values(ascending=True).index[0]
        else:
            # Sort in descending order
            best_score = df_results.mean().sort_values(ascending=False).values[0]
            best_n_neighbors = df_results.mean().sort_values(ascending=False).index[0]

        if verbose:
            print(f"Best score ({scoring}): {best_score}", "\n")
            print(f"Best n_neighbors: {best_n_neighbors}", "\n")

        # Refit the model with the best parameters
        if refit:
            self.n_neighbors = best_n_neighbors

        results_dict = {
            "best_score": best_score,
            "best_n_neighbors": best_n_neighbors,
            "df_results": df_results
        }

        return results_dict


    def leave_n_out_CV(self, n_out=1, n_neighbors=5, verbose=True, refit=False, scoring='mse'):
        """ Leave-n-out Cross-validation"""

        assert self.isFitted, " The model hasn't been fit yet"

        if scoring == 'mse' or scoring == 'c_index':
            scoring_func = self.get_scoring_func(scoring)
        else:
            scoring = 'mse'
            scoring_func = self.get_scoring_func(scoring)
            print("Only 'mse' and 'c_index' scoring fuctions are available for 'leave_n_out_cv'. \n"
                  "'r2'and 'expvar' do not provide a reliable score when scoring less than 5 "
                  f"predictions. \n ")

        X = self.X_train.copy()
        y = self.y_train.copy()
        indexes = list(X.index.values)
        random.Random(4).shuffle(indexes)

        # Get the distances for all the rows of the data
        distances_matrix = [self.get_distances(row) for index, row in self.X_train.iterrows()]

        n_out = n_out

        if len(X) % n_out == 0:
            number_of_samples = int(len(X) / n_out)
        else:
            number_of_samples = int((len(X) // n_out) + 1)

        # Convert to a list if it is not a list
        if not isinstance(n_neighbors, list):
            n_neighbors = [n_neighbors]
        else:
            n_neighbors = n_neighbors

        # Create dataframe to store the r2 scores
        df_results = pd.DataFrame([[None for n in n_neighbors] for i in range(number_of_samples)])
        df_results.columns = [n for n in n_neighbors]
        df_results.index.name = "CV"

        end_loop = False
        while not end_loop:

            for i in range(number_of_samples):

                # Check how many indexes are left
                if len(indexes) <= n_out:
                    # Put the remaining items in the sample and leave the loop run only 1 time more
                    sample = indexes
                    end_loop = True  # This will stop the loop on the next round

                else:
                    sample = [indexes.pop(0) for i in range(n_out)]

                X_test = X.loc[sample]
                y_test = y.loc[sample]

                # Create a dataframe to store the predictions
                df_predictions = pd.DataFrame([[None for n in n_neighbors] for i in sample])
                df_predictions.index = sample
                df_predictions.columns = [n for n in n_neighbors]

                for index, row in X_test.iterrows():
                    # Get all the distances for that data point
                    distances = distances_matrix[index].copy()

                    # Remove the distances of the data points that are present in the test set.
                    # We need to start removing them in descendant order to avoid the change
                    # of index every time an item is removed.
                    for x in sorted(sample)[::-1]:
                        del distances[x]

                    distances.sort(key=lambda tup: tup[1])

                    # Make a prediction for each of the n_neighbors values
                    for n in n_neighbors:
                        df_predictions.loc[index][n] = mean([i[0] for i in distances[:n]])

                for n in n_neighbors:
                    y_pred = df_predictions[n].values
                    score = scoring_func(y_test, y_pred)
                    df_results.loc[i][n] = score
        if scoring == 'mse':
            best_score = df_results.mean().sort_values(ascending=True).values[0]
            best_n_neighbors = df_results.mean().sort_values(ascending=True).index[0]
        else:
            best_score = df_results.mean().sort_values(ascending=False).values[0]
            best_n_neighbors = df_results.mean().sort_values(ascending=False).index[0]

        if verbose:
            print(f"Best score ({scoring}): {best_score}", "\n")
            print(f"Best n_neighbors: {best_n_neighbors}", "\n")

        # Refit the model with the best parameters
        if refit:
            self.n_neighbors = best_n_neighbors

        results_dict = {
            "best_score": best_score,
            "best_n_neighbors": best_n_neighbors,
            "df_results": df_results
        }

        return results_dict


class KNNClassifier:
    """ k Nearest Neighbors prediction model (regression) """

    def __init__(self, n_neighbors=5):
        self.n_neighbors = n_neighbors
        self.X_train = None
        self.y_train = None
        self.isFitted = False

    def euclidean_distance(self, row1, row2):
        """Calculates the Euclidean distance between two vectors"""

        distance = 0.0
        for i in range(len(row1) - 1):
            distance += (row1[i] - row2[i]) ** 2

        return sqrt(distance)

    def get_distances(self, X):
        """Returns a list with all distances"""

        distances = []

        for index, train_row in self.X_train.iterrows():
            dist = self.euclidean_distance(X, train_row)
            distances.append((self.y_train.iloc[index], dist))

        return distances

    def get_neighbors(self, X, n_neighbors=None):
        """Returns the n closest neighbors"""

        assert self.isFitted, " The model hasn't been fit yet"

        if not n_neighbors:
            n_neighbors = self.n_neighbors

        distances = self.get_distances(X)
        distances.sort(key=lambda tup: tup[1])
        neighbors = []
        for i in range(n_neighbors):
            neighbors.append(distances[i][0])

        return neighbors

    def fit(self, X, y):
        """Fits the model to the training data"""

        # Data validation
        X, y = self.data_validation(X, y)

        self.X_train = X.copy().reset_index(drop=True)
        self.y_train = y.copy().reset_index(drop=True)
        self.isFitted = True

        return self

    # Make one or multiple predictions
    def predict(self, X):
        """Make one or multiple predictions"""

        assert self.isFitted, " The model hasn't been fit yet"

        X = self.data_validation(X)

        predictions = []
        if isinstance(X, pd.DataFrame):
            for index, row in X.iterrows():
                neighbors = self.get_neighbors(row)
                predictions.append(max(set(neighbors), key=neighbors.count))

        else:
            neighbors = self.get_neighbors(X)
            predictions.append(max(set(neighbors), key=neighbors.count))

        return predictions

    def get_scoring_func(self, scoring):
        """Returns a scoring function"""

        if scoring == "accuracy":
            scoring_func = accuracy_score
        elif scoring == "precision":
            scoring_func = precision_score
        elif scoring == "recall":
            scoring_func = recall_score
        elif scoring == "f1":
            scoring_func = f1_score
        else:
            scoring_func = accuracy_score
            print(f"Scoring argument '{scoring}' not known, default scoring function return")

        return scoring_func

    def score(self, X, y, scoring='accuracy'):
        """Makes a prediction and returns its scoring"""

        assert self.isFitted, " The model hasn't been fit yet"

        X = self.data_validation(X)

        scoring_func = self.get_scoring_func(scoring)

        y_real = y
        y_predicted = self.predict(X)
        score = scoring_func(y_real, y_predicted)

        return score

    def data_validation(self, X, y=None):
        """Check that the data is in the right format and data type"""

        # Check X:
        # Convert to dataframe if it is a np.dnarray
        if isinstance(X, np.ndarray):
            X = pd.DataFrame(X)
        # Check input data type
        assert isinstance(X, pd.DataFrame) or isinstance(X, pd.Series)
        # Check tha the dataframe only contains numeric values
        assert all(np.issubdtype(dtype, np.number) for dtype in
                   X.dtypes), "X dataframe must contain only numerical values"
        # Check that there aren't missing values
        assert not X.isnull().values.any(), "X contains missing values"

        # Check y:
        if y is not None:
            # Convert to dataframe if it is a np.dnarray
            if isinstance(y, np.ndarray):
                y = pd.DataFrame(y)
            # Check input data type
            assert isinstance(y, pd.DataFrame) or isinstance(y, pd.Series)
            assert len(X) == len(y), "X and y must have same lenght"
            # Check that there aren't missing values
            assert not y.isnull().values.any(), "X contains missing values"

            return X, y
        return X

    def cross_validation(self, cv=10, n_neighbors=5, refit=False, scoring='accuracy',
                         verbose=False):
        """Performs a Cross-validation"""

        assert self.isFitted, " The model hasn't been fit yet"

        scoring_func = self.get_scoring_func(scoring)

        X = self.X_train.copy()
        y = self.y_train.copy()
        indexes = list(X.index.values)
        random.Random(4).shuffle(indexes)

        # Get the distances for all the rows of the data
        distances_matrix = [self.get_distances(row) for index, row in self.X_train.iterrows()]

        # Convert to a list if it is not a list
        if not isinstance(n_neighbors, list):
            n_neighbors = [n_neighbors]
        else:
            n_neighbors = n_neighbors

        cv = cv

        sample_size = (len(X) - 1) // cv

        # Create dataframe to store the r2 scores
        df_results = pd.DataFrame([[None for n in n_neighbors] for i in range(cv)])
        df_results.columns = [n for n in n_neighbors]
        df_results.index.name = "CV"

        for i in range(cv):
            sample = [indexes.pop(0) for i in range(sample_size)]
            X_test = X.loc[sample]
            y_test = y.loc[sample]

            # Create a dataframe to store the predictions
            df_predictions = pd.DataFrame([[None for n in n_neighbors] for i in sample])
            df_predictions.index = sample
            df_predictions.columns = [n for n in n_neighbors]

            for index, row in X_test.iterrows():
                # Get all the distances of that data point
                distances = distances_matrix[index].copy()

                # Remove the distances of the data points that are present in the test set.
                # We need to start removing them in descendant order to avoid the change
                # of index every time an item is removed.
                for x in sorted(sample)[::-1]:
                    del distances[x]
                # Sort the distances
                distances.sort(key=lambda tup: tup[1])

                # Make a prediction for each of the n_neighbors values
                for n in n_neighbors:
                    # Get the closest n neighbours
                    neighbors = [i[0] for i in distances[:n]]

                    prediction = max(set(neighbors), key=neighbors.count)
                    df_predictions.loc[index][n] = prediction

            # Score the prediction and add it to the results dataframe
            for n in n_neighbors:
                y_pred = df_predictions[n].values
                score = scoring_func(list(y_test), list(y_pred))
                df_results.loc[i][n] = score

        best_score = df_results.mean().sort_values(ascending=False).values[0]
        best_n_neighbors = df_results.mean().sort_values(ascending=False).index[0]

        if verbose:
            print(f"Best score ({scoring}): {best_score}", "\n")
            print(f"Best n_neighbors: {best_n_neighbors}", "\n")

        # Refit the model with the best parameters
        if refit:
            self.n_neighbors = best_n_neighbors

        results_dict = {
            "best_score": best_score,
            "best_n_neighbors": best_n_neighbors,
            "df_results": df_results
        }

        return results_dict



# Wine quality dataset

# from sklearn.preprocessing import Normalizer
#
# # Import data
# df = pd.read_csv(r"datasets/Water_data.csv", sep=',')
# normalizer = Normalizer()
#
# #profile = pandas_profiling.ProfileReport(df)
# #profile.to_file("Titanic data profiling.html")
#
# X = df.iloc[:, 1:]
# y = df.iloc[:, 0]
# X = pd.DataFrame(normalizer.fit_transform(X))
#
# results_out = KNNRegressor().fit(X, y).cross_validation(fold=10, n_neighbors=[5, 9], scoring='c_index')

#results_mse = KNNRegressor().fit(X, y).cross_validation(n_neighbors=[5, 9], verbose=True, scoring='mse')
#results_var = KNNRegressor().fit(X, y).cross_validation(n_neighbors=[5, 9], verbose=True, scoring='expvar')
#results_r2 = KNNRegressor().fit(X, y).cross_validation(n_neighbors=[5, 9], verbose=True, scoring='r2')


# from sklearn.model_selection import train_test_split
# from sklearn.preprocessing import MinMaxScaler

# # Import data
# df = pd.read_csv(r"lecture1/datasets/Water_data.csv")
# columns = df.columns
#
# scaler = MinMaxScaler()
#
# X = df.iloc[:, 1:]
# X = pd.DataFrame(scaler.fit_transform(X))
# y = df.iloc[:, 0]
#
# X = scaler.fit_transform(X)
#
# knn = KNN_regressor().fit(X, y)
#
# results = knn.cross_validation(fold=10, n_neighbors=[n for n in range(2, 6)], refit=True)

# # Split the data in training data and test data
# X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.25, random_state=1)
#
# # Create and instance of our KNN_regressor
# knn = KNN_regressor(n_neighbors=5)
#
# # Fit the model and make prediction
# y_pred = knn.fit(X_train, y_train).predict(X_test)
#
# prediction_table = pd.DataFrame(
#     {'y_pred': y_pred,
#      'y_test': list(y_test),
#      })
#
# prediction_table.head(10)
#
# # Evaluate the model
# r2_score = knn.score(X_test, y_test)
#
#
# from sklearn import metrics
#
# MAE = metrics.mean_absolute_error(y_test, y_pred)
# MSE = metrics.mean_squared_error(y_test, y_pred)
# RMSE = np.sqrt(metrics.mean_squared_error(y_test, y_pred))
# Explained_variance = metrics.explained_variance_score(y_test, y_pred)
# r2 = metrics.r2_score(y_test, y_pred)
#
# evaluation = pd.DataFrame([[MAE , MSE, RMSE, Explained_variance, r2]],
#                columns = ['MAE', 'MSE', 'RMSE', 'Explained variance', 'r2 Score'])
#
# print(evaluation)


# # comparison with sklearn

# # Split the data in training data and test data
# X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.25, random_state=1)
#
# my_pred = KNN_regressor(n_neighbors=5).fit(X_train, y_train).predict(X_test)
#
# sklearn_pred = KNeighborsRegressor(n_neighbors=5, metric='euclidean').fit(X_train, y_train).predict(X_test)
#
# real_pred = y_test
#
# data = pd.DataFrame([my_pred, sklearn_pred, real_pred])


# # timing with and with re-using distances
#
# knn = KNN_regressor().fit(X, y)
#
# start = timer()
# knn.cross_validation(fold=10, n_neighbors=[n for n in range(2, 10)], refit=True)
# end = timer()
# print(f"Re-using distances: {round(end - start, 2)} seconds \n")
#
# start = timer()
# knn.cv_without_reusing_distances(fold=10, n_neighbors=[n for n in range(2, 10)], refit=True)
# end = timer()
# print(f"Without re-using distances: {round(end - start, 2)} seconds \n")
#
#
# # Normalization comparison
#
# from sklearn.preprocessing import MinMaxScaler, Normalizer, StandardScaler, QuantileTransformer
#
# # Import data
# df = pd.read_csv(r"lecture1/datasets/Water_data.csv")
#
# scalers = [
#     MinMaxScaler(),
#     StandardScaler(),
#     Normalizer(),
#     QuantileTransformer(output_distribution="uniform")
# ]
#
# X = df[["Mod1", "Mod2", "Mod3"]]
# c_total = df["c_total"]
# Cd = df["Cd"]
# Pb = df["Pb"]
#
# analytes = [c_total, Cd, Pb]
#
# # Data frame to store the results
# df_results = pd.DataFrame([[None for analyte in analytes] for scaler in scalers])
# df_results.columns = [analyte.name for analyte in analytes]
# df_results.index = [type(scaler).__name__ for scaler in scalers]
#
# for scaler in scalers:
#     X = scaler.fit_transform(X) # TODO This is wrong, change X
#
#     for analyte in analytes:
#         knn = KNN_regressor().fit(X, analyte)
#         results = knn.cross_validation(fold=10, n_neighbors=[n for n in range(2, 10)], refit=True)
#
#         df_results.loc[type(scaler).__name__][analyte.name] = f"R2: {round(results['best_r2_score'], 2)} " \
#             f"(k:{results['best_n_neighbors']})"
#
# print(df_results)

# Normalization provides the best results as was to expect. When k-NN uses Euclidean
# distance as a distance metric, in order for all of the features to be of equal importance
# when calculating the distance, the features must have the same range of values. This is
# only achievable through normalization.

# We can not predict the level of Cd...