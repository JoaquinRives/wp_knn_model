import numpy as np
import pandas as pd
import random
from sklearn.model_selection import train_test_split
from knn_model.cross_validation import spatial_cross_validation,\
    spatial_CV_knn_optimized
from knn_model.data_management import load_data
from sklearn.preprocessing import StandardScaler

# # Spliting training and test data sets
#####################################################
#
# X, y = load_data('training')
#
# X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.25)
#
# output_train = pd.DataFrame(y_train.values)
# output_train.to_csv('water_permeability_model/data/OUTPUT_TRAIN.csv', header=False, index=False)
#
# output_test = pd.DataFrame(y_test.values)
# output_test.to_csv('water_permeability_model/data/OUTPUT_TEST.csv', header=False, index=False)
#
# coordinates_test = X_test[['coordinate_x', 'coordinate_y']]
# coordinates_test.to_csv('water_permeability_model/data/COORDINATES_TEST.csv', header=False, index=False)
#
# coordinates_train = X_train[['coordinate_x', 'coordinate_y']]
# coordinates_train.to_csv('water_permeability_model/data/COORDINATES_TRAIN.csv', header=False, index=False)
#
# input_data_train = X_train.drop(['c_x', 'c_y', 'coordinate_x', 'coordinate_y'], axis=1)
# input_data_train.to_csv('water_permeability_model/data/INPUT_TRAIN.csv', header=False, index=False)
#
# input_data_test = X_test.drop(['c_x', 'c_y', 'coordinate_x', 'coordinate_y'], axis=1)
# input_data_test.to_csv('water_permeability_model/data/INPUT_TEST.csv', header=False, index=False)

#########################################################################

# # P-values
###################################################
# from water_permeability_model import pipeline
# from water_permeability_model.c_index import c_index
#
# scores = []
#
# X_train, y_train = load_data('train')
# X_test, y_test = load_data('test')
#
# y_test = list(y_test['target'].values)
# y_train = list(y_train['target'].values)
#
# pipeline.pipe.fit(X_train, y_train)
# y_pred = pipeline.pipe.predict(X_test)
# score = c_index(list(y_test), list(y_pred))
# scores.append(score)
#
# for i in range(20):
#     X_train, y_train = load_data('train')
#     X_test, y_test = load_data('test')
#
#     y_test = list(y_test['target'].values)
#     y_train = list(y_train['target'].values)
#
#     random.shuffle(y_test)
#     random.shuffle(y_train)
#
#     pipeline.pipe.fit(X_train, y_train)
#
#     y_pred = pipeline.pipe.predict(X_test)
#
#     score = c_index(list(y_test), list(y_pred))
#     scores.append(score)
#
####################################################

# #######################################

input_data = pd.read_csv(r'D:\OneDrive\Joaquin\University\0 Applications of Data Analysis\lecture4\water_permeability_model\water_permeability_model\data\INPUT.csv', header=None)

coordinates = pd.read_csv(r'D:\OneDrive\Joaquin\University\0 Applications of Data Analysis\lecture4\water_permeability_model\water_permeability_model\data\COORDINATES.csv', header=None)
coordinates.columns = ['c_x', 'c_y']

output = pd.read_csv(r'D:\OneDrive\Joaquin\University\0 Applications of Data Analysis\lecture4\water_permeability_model\water_permeability_model\data\OUTPUT.csv', header=None)
output.columns = ['target']
output = output

df = pd.concat([input_data, coordinates], axis=1)

# Standardization
scaler = StandardScaler()
df = pd.DataFrame(scaler.fit_transform(df))

coordinates.columns = ['coordinate_x', 'coordinate_y']
df = pd.concat([df, coordinates], axis=1)

df = pd.concat([df, output], axis=1)

X = df.drop('target', axis=1)
y = df['target']

from sklearn.neighbors import KNeighborsRegressor
knn = KNeighborsRegressor(metric='euclidean', n_neighbors=5)

scores = spatial_cross_validation(model=knn, X=X, y=y, radius=100, scoring='c_index')
scores = spatial_CV_knn_optimized(model=knn, X=X, y=y, radius=100, scoring='c_index')
